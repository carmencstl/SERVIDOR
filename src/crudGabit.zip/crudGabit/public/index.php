<?php
// 1. Iniciar sesión siempre antes de cargar clases
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../vendor/autoload.php';

use CrudGabit\Config\Router;
use CrudGabit\Controladores\AuthController;
use CrudGabit\Config\Session;
use CrudGabit\Config\Request;

$router = new Router('/crudGabit');

// Rutas de Autenticación
$router->get("/", [AuthController::class, "showLogin"]);
$router->get("/login", [AuthController::class, "showLogin"]);
$router->post("/login", [AuthController::class, "login"]);
$router->get("/register", [AuthController::class, "showRegister"]);
$router->post("/register", [AuthController::class, "register"]);
$router->get("/logout", [AuthController::class, "logout"]);

// NUEVA RUTA: Dashboard (Debes registrarla para que no de 404)
// Esta ruta "crea" virtualmente el dashboard
$router->get("/dashboard", function() {
    if (\CrudGabit\Config\Session::active()) {
        echo "<h1>¡Bienvenido al Dashboard!</h1>";
        echo "<p>Has iniciado sesión con éxito.</p>";
    } else {
        \CrudGabit\Config\Request::redirect("/login");
    }
});

$router->run();