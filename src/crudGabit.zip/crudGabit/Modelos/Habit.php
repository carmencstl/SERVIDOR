<?php

namespace Modelos;

class Habit
{

}