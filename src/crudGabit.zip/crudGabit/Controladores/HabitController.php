<?php

namespace CrudGabit\Controladores;

use CrudGabit\Config\Request;
use CrudGabit\Modelos\Habito;
use CrudGabit\Enums\Categoria;
class HabitController extends BaseController
{
    public function __construct()
    {
        $loader = new \Twig\Loader\FilesystemLoader(__DIR__ . "/../Vistas");
        $this->twig = new \Twig\Environment($loader);
    }

    /**
     * Mostrar la lista de hábitos
     * @return void
     */
    public function index(): void
    {
        $habitos = Habito::getHabitsByUser();

        echo $this->render("habits/index.twig", [
            "habits" => $habitos
        ]);
    }

    /**
     * Borrar un hábito por su ID
     * @return void
     */
    public function deleteHabit(): void
    {
        $idHabit = (int)Request::post("idCamino");
        Habito::deleteHabitById($idHabit);
        Request::redirect("/crudGabit/habits");
    }

    /**
     * Actualizar un hábito existente
     * @return void
     */
    public function updateHabit(): void
    {
        $idHabito = (int)Request::post("idCamino");
        $nombreUsuario = Request::post("nombreHabito");
        $descripcion = Request::post("descripcion");
        $categoria = Request::post("categoria");

        Habito::actualizarHabito($idHabito, $nombreUsuario, $descripcion, $categoria);

        Request::redirect("/crudGabit/habits");
    }

    /**
     * Mostrar el formulario de edición de un hábito
     * @return void
     */
    public function showEdit(): void
    {
        $habit = Habito::getById((int)Request::get("idCamino"));
        $categorias = Categoria::toArray();
        echo $this->render("habits/edit.twig", [
            "habit" => $habit,
            "categorias" => $categorias
        ]);
    }

    /**
     * Mostrar el formulario de creación de un nuevo hábito
     * @return void
     */
    public function showCreate(): void
    {
        $categorias = Categoria::toArray();
        echo $this->render("habits/create.twig", [
            "categorias" => $categorias
        ]);
    }

    /**
     * Crear un nuevo hábito
     * @return void
     */
    public function createHabit(): void
    {
        $nombre = Request::post("nombreHabito");
        $descripcion = Request::post("descripcion");
        $categoria = Request::post("categoria");
        $habito = Habito::crearHabito($nombre, $descripcion, $categoria);
        $habito->insertarHabitoEnBD();
        Request::redirect("/crudGabit/habits");
    }
}