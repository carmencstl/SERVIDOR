<?php

namespace CrudGabit\Controladores;

use CrudGabit\Modelos\Habito;
use CrudGabit\Modelos\Logro;
use CrudGabit\Config\Request;

class LogroController extends BaseController
{


    /**
     * Muestra la lista de logros del usuario.
     * @return void
     *
     */
    public function index(): void
    {
        $logros = Logro::getLogrosByUser();
        echo $this->render("achievements/index.twig", [
            "logros" => $logros
        ]);
    }

    /**
     * Elimina un logro por su ID.
     * @return void
     */
    public function deleteLogro(): void
    {
        $idLogro = (int)Request::post("idLogro");
        Logro::deleteLogroById($idLogro);
        Request::redirect("/crudGabit/achievements");
    }

    /**
     * Muestra el formulario de edición de un logro.
     * @return void
     */
    public function showEdit(): void
    {
        $logro = Logro::getById((int)Request::get("idLogro"));
        echo $this->render("achievements/edit.twig", [
            "logro" => $logro
        ]);
    }

    /**
     * Actualiza un logro con los datos del formulario.
     * @return void
     */
    public function updateLogro(): void
    {
        $idLogro = (int)Request::post("idLogro");
        $nombreLogro = Request::post("nombre");
        $descripcion = Request::post("descripcion");

        Logro::actualizarLogro($idLogro, $nombreLogro, $descripcion);

        Request::redirect("/crudGabit/achievements");
    }

    /**
     * Muestra el formulario para crear un nuevo logro.
     * @return void
     */
    public function showCreate(): void
    {
        $habitosDisponibles = Habito::getHabitsByUser();
        echo $this->render("achievements/create.twig",
        [
            "habitos" => $habitosDisponibles
        ]);
    }

    /**
     * Crea un nuevo logro con los datos del formulario.
     * @return void
     */
    public function createLogro(): void
    {
        $nombreLogro = Request::post("nombreLogro");
        $descripcion = Request::post("descripcion");
        $habito = Request::post("idCamino");

        $logro = Logro::crearLogro($nombreLogro, $descripcion, $habito);
        $logro->insertarLogroEnBD();
        Request::redirect("/crudGabit/achievements");
    }

}