<?php

namespace CrudGabit\Controladores;

use CrudGabit\Config\Request;
use CrudGabit\Config\Router;
use CrudGabit\Config\Session;
use CrudGabit\Modelos\Usuario;
use CrudGabit\Config\Auth;

class UserController extends BaseController
{

    /**
     * Mostrar la lista de usuarios
     * @return void
     *
     */
    public function index(): void
    {
        Router::protectAdmin("/dashboard");
        $usuarios = Usuario::getAllUsers();
        echo $this->render("users/index.twig", [
            "usuarios" => $usuarios
        ]);
    }

    /**
     * Borrar un usuario por su ID
     * @return void
     */
    public static function borrarUsuario(): void
    {
        $idUsuario = Request::post("idUsuario");
        Usuario::deleteUserById((int)$idUsuario);
        Request::redirect("/crudGabit/users");
    }


    /**
     * Mostrar el formulario de edición de usuario
     * @return void
     */
    public function showEdit(): void
    {
        $usuario = Usuario::getById((int)Request::get("idUsuario"));
        echo $this->render("users/edit.twig", [
            "usuario" => $usuario
        ]);
    }

    /**
     * Editar un usuario existente
     * @return void
     */
    public function editarUsuario(): void
    {
        $idUsuario = (int)Request::post("idUsuario");
        $nombreUsuario = Request::post("nombreUsuario");
        $nombre = Request::post("nombre");
        $email = Request::post("email");
        $rol = Request::post("rol");
        $apellidos = Request::post("apellidos");

        Usuario::actualizarUsuario($idUsuario, $nombreUsuario, $nombre, $apellidos, $email, $rol);
        Request::redirect("/crudGabit/users");
    }

    /**
     * Mostrar el formulario de creación de usuario
     * @return void
     */
    public function showCreate(): void
    {
        Router::protectAdmin("/dashboard");

        $success = Session::get("success");
        $error = Session::get("error");

        Session::delete("success");
        Session::delete("error");

        echo $this->render("users/create.twig", [
            "success" => $success,
            "error" => $error
        ]);
    }

    /**
     * Crear un nuevo usuario
     * @return void
     */
    public static function createUser(): void
    {
        if (is_object(Usuario::getByEmail(Request::post("email")))) {
            Session::set("error", "El email ya está registrado. Por favor, usa otro email.");
        } else {
            $usuario = Usuario::crear(
                Request::post("nombreUsuario") ?? "",
                Request::post("nombre") ?? "",
                Request::post("apellidos") ?? "",
                Request::post("email") ?? "",
                Request::post("password") ?? "",
                Request::post("rol") ?? "usuario"
            );

            if ($usuario->insertarUsuario()) {
                Session::set("success", "Usuario creado correctamente.");
            } else {
                Session::set("error", "Error al crear el usuario. Inténtalo de nuevo.");
            }
        }

        Request::redirect("/crudGabit/users/create");
    }


}