<?php

namespace Modelos;

class Camino
{

}